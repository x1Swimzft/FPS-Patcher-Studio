﻿FPS Patcher Studio v0.2.1-beta (Windows 64-bit, portable)

Run:   FPSPatcherStudio.exe   (no install needed; delete the folder to remove)
Data:  %APPDATA%\FPSPatcherStudio  (settings.json, queue.json, logs)

Presets (v0.2.1-beta):
  - Bxd For PC (bxd-pc): Original BXD trick (indeterminate mvhd, 10x audio ghosts, trailing bytes).
  - BXD For Mobile (bxd-mobile): ISO-BMFF compliant container for iOS AVPlayer / Android MediaCodec.
  - BXD Hybrid (bxd-hybrid): Valid mvhd/tkhd/edts + bounded last-sample audio tail extension + free box.
  - BXD Clean (bxd-clean): Pure video timescale/stts/ctts patch (audio untouched).
  - Repair for Mobile: Lossless 6-step repair for existing BXD-patched files.

FFmpeg is OPTIONAL (used for video thumbnails).
  - Put ffmpeg.exe + ffprobe.exe in a 'bin' folder next to FPSPatcherStudio.exe,
    set the folder in Settings > FFmpeg, or have them on PATH.

Notes:
  - Nothing here is verified to change TikTok or any platform's output resolution.
  - Windows SmartScreen may warn: the exe is unsigned.
