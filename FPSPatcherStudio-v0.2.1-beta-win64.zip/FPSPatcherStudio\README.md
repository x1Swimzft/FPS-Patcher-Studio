# FPS Patcher Studio

Desktop tool (Python + CustomTkinter) that patches MP4/MOV atom timing structures directly at the ISO-BMFF container level — zero re-encode, bit-exact video/audio sample preservation.

## Requirements
- Python 3.11+, [uv](https://docs.astral.sh/uv/)
- Optional: FFmpeg (`ffmpeg` + `ffprobe`) for legacy fallback or external verification.

## Run
```powershell
uv sync
uv run fps-patcher-studio      # or: uv run python -m fps_patcher
```

## Presets
1. **Bxd For Mobile (`bxd-mobile`)** *(Default)*:
   - Scales video `mdhd`, `stts`, `ctts`, and reconstructs `tkhd`/`mvhd`/`elst` timing accurately.
   - Appends a standard ISO-BMFF `free` padding box (or 64-bit `largesize` `free` box) at EOF instead of raw out-of-box bytes.
   - Keeps `mdat` and real audio samples untouched (`Structure OK (likely mobile-compatible)`).
2. **Bxd Hybrid (PC + Mobile) (`bxd-hybrid`)**:
   - Mobile-compatible container with a valid `free` padding box plus an optional tiny in-`mdat` audio tail (`<= 200 ms` default) with valid chunk offsets.
3. **Bxd Clean Timescale (`bxd-clean`)**:
   - Pure lossless `moov` header & timing rewrite (`faststart`, no extra padding bytes).
4. **Bxd For PC (`bxd-pc`)**:
   - Legacy experimental BXD mode (`mvhd.duration = -1`, 10x audio ghost inflation, raw trailing bytes outside top-level boxes). Works on PC players, but likely fails on iOS/Android hardware decoders.

## Repair & Diagnostics
- **Repair for Mobile**: Right-click any queued clip or use the **MP4 Forensic** window to losslessly strip legacy BXD ghost samples/raw trailing bytes, reconstruct `edts`/`elst` from `ctts` B-frame offsets, recalculate `tkhd`/`mvhd` durations, and verify SHA-256 sample integrity.
- **Diagnostic Logger**: Automatically writes structured `<5 MB` diagnostic reports to `%LOCALAPPDATA%\FPSPatcherStudio\logs\` (rotates last 20 `auto_patch_*.log` files; masks local user paths by default) and supports one-click **Save Diagnostic Log** export.

## Important caveat
Changing the timescale re-expresses each frame's duration in a new time unit; it does **not** change the real frame rate (a 30 fps clip still plays at 30 fps). Any effect on how a platform such as TikTok processes the upload depends on that platform's undocumented ingest pipeline and may change at any time.

## Develop
```powershell
uv run pytest -q
uv run ruff check src tests
uv run mypy
```

## Build (Windows)
```powershell
powershell -ExecutionPolicy Bypass -File build/release.ps1
```
Produces both the portable `.zip` and the Inno Setup installer (`Output/FPSPatcherStudio-Setup-*.exe`).

